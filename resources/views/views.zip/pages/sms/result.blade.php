@extends('layouts.navbar')
@section('pageHeader')
@section('content')
<div class="row">
	<div class="col-lg-12">
	    <h2 class="page-header">
	         SMS
	    </h2>
	</div>
	<div class="col-lg-8">
		<h3>{{$r}}</h3>
	</div>
</div>
@stop
